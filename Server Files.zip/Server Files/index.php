<html>

<head>
    <title> SENIOR MODS </title>
    <link rel="stylesheet" href="assets/stylegg.css">
</head>

<body>
    <canvas id="canvas" width="1400" height="600">
</canvas>
    <script src="assets/script.js">
    </script>
</body>

</html>